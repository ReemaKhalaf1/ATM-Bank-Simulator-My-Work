package com.atmbanksimulator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 Test Suite for ATM Bank Simulator
 *
 * Covers:
 *  - BankAccount  : deposit, withdraw, password, mini statement
 *  - Bank         : login, lockout, transfer, currency exchange
 *  - StudentAccount: daily withdrawal limit
 *  - PrimeAccount : overdraft behaviour
 *  - SavingAccount: interest calculation
 */
public class BankTest {

    // ---------------------------------------------------------------
    // Shared test fixtures — recreated fresh before every single test
    // ---------------------------------------------------------------
    private Bank bank;
    private BankAccount account;

    @BeforeEach
    void setUp() {
        bank = new Bank();
        // Add a standard account used across most tests
        bank.addBankAccount("12345", "pass1234", 500);
        account = new BankAccount("99999", "abcd", 200);
    }


    // ===============================================================
    //  BANKACCOUNT — deposit
    // ===============================================================

    @Test
    void deposit_validAmount_increasesBalance() {
        account.deposit(100);
        assertEquals(300, account.getBalance());
    }

    @Test
    void deposit_zero_balanceUnchanged() {
        account.deposit(0);
        assertEquals(200, account.getBalance());
    }

    @Test
    void deposit_negativeAmount_returnsFalse() {
        boolean result = account.deposit(-50);
        assertFalse(result);
        assertEquals(200, account.getBalance()); // balance must not change
    }

    @Test
    void deposit_recordsTransaction() {
        account.deposit(100);
        assertEquals(1, account.getTransactionCount());
    }


    // ===============================================================
    //  BANKACCOUNT — withdraw
    // ===============================================================

    @Test
    void withdraw_validAmount_decreasesBalance() {
        account.withdraw(50);
        assertEquals(150, account.getBalance());
    }

    @Test
    void withdraw_exactBalance_leavesZero() {
        account.withdraw(200);
        assertEquals(0, account.getBalance());
    }

    @Test
    void withdraw_moreThanBalance_returnsFalse() {
        boolean result = account.withdraw(999);
        assertFalse(result);
        assertEquals(200, account.getBalance()); // balance must not change
    }

    @Test
    void withdraw_negativeAmount_returnsFalse() {
        boolean result = account.withdraw(-10);
        assertFalse(result);
    }

    @Test
    void withdraw_recordsTransaction() {
        account.withdraw(50);
        assertEquals(1, account.getTransactionCount());
    }


    // ===============================================================
    //  BANKACCOUNT — changePassword
    // ===============================================================

    @Test
    void changePassword_correctOld_returnsTrue() {
        boolean result = account.changePassword("abcd", "newpass");
        assertTrue(result);
    }

    @Test
    void changePassword_wrongOld_returnsFalse() {
        boolean result = account.changePassword("wrong", "newpass");
        assertFalse(result);
    }

    @Test
    void changePassword_tooShortNewPassword_returnsFalse() {
        // New password must be at least 4 characters
        boolean result = account.changePassword("abcd", "123");
        assertFalse(result);
    }

    @Test
    void changePassword_exactlyFourChars_returnsTrue() {
        boolean result = account.changePassword("abcd", "1234");
        assertTrue(result);
    }


    // ===============================================================
    //  BANKACCOUNT — getMiniStatement
    // ===============================================================

    @Test
    void getMiniStatement_noTransactions_returnsNoTransactionsMessage() {
        String result = account.getMiniStatement();
        assertEquals("No transactions recorded yet.", result);
    }

    @Test
    void getMiniStatement_afterDeposit_containsBalance() {
        account.deposit(100);
        String result = account.getMiniStatement();
        assertTrue(result.contains("300")); // new balance should appear
    }


    // ===============================================================
    //  BANK — login
    // ===============================================================

    @Test
    void login_correctCredentials_returnsTrue() {
        boolean result = bank.login("12345", "pass1234");
        assertTrue(result);
    }

    @Test
    void login_wrongPassword_returnsFalse() {
        boolean result = bank.login("12345", "wrongpass");
        assertFalse(result);
    }

    @Test
    void login_nonExistentAccount_returnsFalse() {
        boolean result = bank.login("00000", "pass1234");
        assertFalse(result);
    }

    @Test
    void login_success_loggedInIsTrue() {
        bank.login("12345", "pass1234");
        assertTrue(bank.loggedIn());
    }

    @Test
    void logout_afterLogin_loggedInIsFalse() {
        bank.login("12345", "pass1234");
        bank.logout();
        assertFalse(bank.loggedIn());
    }


    // ===============================================================
    //  BANK — account lockout after 3 failed attempts
    // ===============================================================

    @Test
    void login_threeFailedAttempts_accountBecomesLocked() {
        bank.login("12345", "wrong");
        bank.login("12345", "wrong");
        bank.login("12345", "wrong");
        assertTrue(bank.isAccountLocked("12345"));
    }

    @Test
    void login_twoFailedAttempts_accountNotYetLocked() {
        bank.login("12345", "wrong");
        bank.login("12345", "wrong");
        assertFalse(bank.isAccountLocked("12345"));
    }

    @Test
    void login_threeFailedAttempts_correctPasswordThenRejected() {
        bank.login("12345", "wrong");
        bank.login("12345", "wrong");
        bank.login("12345", "wrong");
        // Even correct password should now be rejected while locked
        boolean result = bank.login("12345", "pass1234");
        assertFalse(result);
    }

    @Test
    void getRemainingLoginAttempts_afterOneFailure_returnsTwo() {
        bank.login("12345", "wrong");
        assertEquals(2, bank.getRemainingLoginAttempts("12345"));
    }


    // ===============================================================
    //  BANK — deposit and withdraw (through Bank, requires login)
    // ===============================================================

    @Test
    void deposit_whenLoggedIn_balanceIncreases() {
        bank.login("12345", "pass1234");
        bank.deposit(200);
        assertEquals(700, bank.getBalance());
    }

    @Test
    void withdraw_whenLoggedIn_balanceDecreases() {
        bank.login("12345", "pass1234");
        bank.withdraw(100);
        assertEquals(400, bank.getBalance());
    }

    @Test
    void deposit_whenNotLoggedIn_returnsFalse() {
        boolean result = bank.deposit(100);
        assertFalse(result);
    }

    @Test
    void withdraw_whenNotLoggedIn_returnsFalse() {
        boolean result = bank.withdraw(100);
        assertFalse(result);
    }


    // ===============================================================
    //  BANK — transfer between accounts
    // ===============================================================

    @Test
    void transfer_validAmount_movesMoneyBetweenAccounts() {
        bank.addBankAccount("67890", "pass5678", 100);
        bank.login("12345", "pass1234");
        bank.transfer("67890", 200);
        assertEquals(300, bank.getBalance()); // sender lost 200
    }

    @Test
    void transfer_toNonExistentAccount_returnsFalse() {
        bank.login("12345", "pass1234");
        boolean result = bank.transfer("99999", 100);
        assertFalse(result);
    }

    @Test
    void transfer_toSameAccount_returnsFalse() {
        bank.login("12345", "pass1234");
        boolean result = bank.transfer("12345", 100);
        assertFalse(result);
    }

    @Test
    void transfer_moreThanBalance_returnsFalse() {
        bank.addBankAccount("67890", "pass5678", 100);
        bank.login("12345", "pass1234");
        boolean result = bank.transfer("67890", 9999);
        assertFalse(result);
    }


    // ===============================================================
    //  BANK — currency exchange
    // ===============================================================

    @Test
    void convertCurrency_validCurrency_containsResult() {
        bank.login("12345", "pass1234");
        String result = bank.convertCurrency(100, "USD");
        assertTrue(result.contains("USD"));
    }

    @Test
    void convertCurrency_unsupportedCurrency_returnsErrorMessage() {
        bank.login("12345", "pass1234");
        String result = bank.convertCurrency(100, "XYZ");
        assertTrue(result.contains("not supported"));
    }

    @Test
    void convertCurrency_lowercaseInput_stillWorks() {
        bank.login("12345", "pass1234");
        String result = bank.convertCurrency(100, "eur");
        assertTrue(result.contains("EUR"));
    }


    // ===============================================================
    //  BANK — createAccount
    // ===============================================================

    @Test
    void createAccount_newAccount_returnsTrue() {
        boolean result = bank.createAccount("11111", "securepass", Bank.AccountType.STANDARD, 0);
        assertTrue(result);
    }

    @Test
    void createAccount_duplicateAccountNumber_returnsFalse() {
        boolean result = bank.createAccount("12345", "securepass", Bank.AccountType.STANDARD, 0);
        assertFalse(result);
    }

    @Test
    void createAccount_passwordTooShort_returnsFalse() {
        boolean result = bank.createAccount("22222", "abc", Bank.AccountType.STANDARD, 0);
        assertFalse(result);
    }


    // ===============================================================
    //  STUDENTACCOUNT — daily withdrawal limit
    // ===============================================================

    @Test
    void studentAccount_withdrawWithinLimit_succeeds() {
        StudentAccount student = new StudentAccount("S001", "pass", 500);
        boolean result = student.withdraw(30);
        assertTrue(result);
        assertEquals(470, student.getBalance());
    }

    @Test
    void studentAccount_withdrawExactDailyLimit_succeeds() {
        StudentAccount student = new StudentAccount("S001", "pass", 500);
        boolean result = student.withdraw(50); // daily limit is exactly 50
        assertTrue(result);
    }

    @Test
    void studentAccount_withdrawOverDailyLimit_returnsFalse() {
        StudentAccount student = new StudentAccount("S001", "pass", 500);
        boolean result = student.withdraw(51); // one over the daily limit
        assertFalse(result);
        assertEquals(500, student.getBalance()); // balance unchanged
    }

    @Test
    void studentAccount_twoPart_withdrawalsExceedLimit_secondFails() {
        StudentAccount student = new StudentAccount("S001", "pass", 500);
        student.withdraw(30);
        boolean result = student.withdraw(30); // 30+30=60, exceeds 50
        assertFalse(result);
    }

    @Test
    void studentAccount_getRemainingLimit_correctAfterWithdrawal() {
        StudentAccount student = new StudentAccount("S001", "pass", 500);
        student.withdraw(20);
        assertEquals(30, student.getRemainingLimit());
    }

    @Test
    void studentAccount_resetDailyLimit_allowsWithdrawalAgain() {
        StudentAccount student = new StudentAccount("S001", "pass", 500);
        student.withdraw(50);
        student.resetDailyLimit();
        boolean result = student.withdraw(50);
        assertTrue(result);
    }

    @Test
    void studentAccount_getAccountTypeName_returnsStudent() {
        StudentAccount student = new StudentAccount("S001", "pass", 100);
        assertEquals("STUDENT", student.getAccountTypeName());
    }


    // ===============================================================
    //  PRIMEACCOUNT — overdraft
    // ===============================================================

    @Test
    void primeAccount_withdrawWithinBalance_succeeds() {
        PrimeAccount prime = new PrimeAccount("P001", "pass", 200);
        boolean result = prime.withdraw(100);
        assertTrue(result);
        assertEquals(100, prime.getBalance());
    }

    @Test
    void primeAccount_withdrawIntoOverdraft_succeeds() {
        PrimeAccount prime = new PrimeAccount("P001", "pass", 50);
        boolean result = prime.withdraw(100); // goes £50 into overdraft
        assertTrue(result);
        assertEquals(-50, prime.getBalance());
    }

    @Test
    void primeAccount_withdrawExactOverdraftLimit_succeeds() {
        PrimeAccount prime = new PrimeAccount("P001", "pass", 0);
        boolean result = prime.withdraw(100); // exactly at the overdraft limit
        assertTrue(result);
        assertEquals(-100, prime.getBalance());
    }

    @Test
    void primeAccount_withdrawBeyondOverdraftLimit_returnsFalse() {
        PrimeAccount prime = new PrimeAccount("P001", "pass", 50);
        boolean result = prime.withdraw(200); // 200 > 50 + 100 overdraft
        assertFalse(result);
        assertEquals(50, prime.getBalance()); // balance unchanged
    }

    @Test
    void primeAccount_getOverdraftRemaining_correctWhenInOverdraft() {
        PrimeAccount prime = new PrimeAccount("P001", "pass", 0);
        prime.withdraw(40);
        assertEquals(60, prime.getOverdraftRemaining()); // 100 - 40 = 60
    }

    @Test
    void primeAccount_getAccountTypeName_returnsPrime() {
        PrimeAccount prime = new PrimeAccount("P001", "pass", 100);
        assertEquals("PRIME", prime.getAccountTypeName());
    }


    // ===============================================================
    //  SAVINGACCOUNT — interest
    // ===============================================================

    @Test
    void savingAccount_addInterest_increasesBalance() {
        SavingAccount saving = new SavingAccount("V001", "pass", 1000);
        saving.addInterest();
        assertEquals(1020, saving.getBalance()); // 2% of 1000 = 20
    }

    @Test
    void savingAccount_addInterest_onZeroBalance_noChange() {
        SavingAccount saving = new SavingAccount("V001", "pass", 0);
        saving.addInterest();
        assertEquals(0, saving.getBalance());
    }

    @Test
    void savingAccount_addInterest_roundsDown() {
        SavingAccount saving = new SavingAccount("V001", "pass", 99);
        saving.addInterest(); // 2% of 99 = 1.98 → rounds down to 1
        assertEquals(100, saving.getBalance());
    }

    @Test
    void savingAccount_getInterestRate_returnsTwoPercent() {
        SavingAccount saving = new SavingAccount("V001", "pass", 500);
        assertEquals(0.02, saving.getInterestRate(), 0.0001);
    }

    @Test
    void savingAccount_getInterestPreview_containsRate() {
        SavingAccount saving = new SavingAccount("V001", "pass", 1000);
        String preview = saving.getInterestPreview();
        assertTrue(preview.contains("2")); // rate shown as 2%
    }

    @Test
    void savingAccount_getInterestPreview_zeroBalance_returnsNotApplicable() {
        SavingAccount saving = new SavingAccount("V001", "pass", 0);
        String preview = saving.getInterestPreview();
        assertTrue(preview.contains("No interest applicable"));
    }

    @Test
    void savingAccount_getAccountTypeName_returnsSaving() {
        SavingAccount saving = new SavingAccount("V001", "pass", 100);
        assertEquals("SAVING", saving.getAccountTypeName());
    }
}
