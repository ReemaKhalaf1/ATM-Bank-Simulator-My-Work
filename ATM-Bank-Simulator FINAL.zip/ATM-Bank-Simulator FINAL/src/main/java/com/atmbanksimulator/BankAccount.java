package com.atmbanksimulator;

import java.util.ArrayList;

public class BankAccount implements java.io.Serializable {

    private String accNumber = "";
    private String accPasswd = "";
    protected int balance = 0;
    private ArrayList<Transaction> transactions = new ArrayList<>();
    private String lastLoginTime = "";
    private static final int MAX_TRANSACTION_HISTORY = 50;

    public BankAccount() {}

    public BankAccount(String a, String p, int b) {
        accNumber = a;
        accPasswd = p;
        balance = b;
    }

    public void setLastLoginTime(String time) {
        this.lastLoginTime = time;
    }

    public String getLastLoginTime() {
        return lastLoginTime.isEmpty() ? "First login ever" : lastLoginTime;
    }

    protected void recordTransaction(Transaction.TransactionType type, int amount) {
        transactions.add(new Transaction(type, amount, balance));
        if (transactions.size() > MAX_TRANSACTION_HISTORY) {
            transactions.remove(0);
        }
    }

    public boolean withdraw(int amount) {
        if (amount < 0 || balance < amount) return false;
        balance = balance - amount;
        recordTransaction(Transaction.TransactionType.WITHDRAWAL, amount);
        return true;
    }

    public boolean deposit(int amount) {
        if (amount < 0) return false;
        balance = balance + amount;
        recordTransaction(Transaction.TransactionType.DEPOSIT, amount);
        return true;
    }

    public int getBalance() {
        return balance;
    }

    public String getAccNumber() {
        return accNumber;
    }

    public String getaccPasswd() {
        return accPasswd;
    }

    protected void setBalance(int newBalance) {
        this.balance = newBalance;
    }

    public boolean changePassword(String oldPassword, String newPassword) {
        if (this.accPasswd.equals(oldPassword)) {
            if (newPassword != null && newPassword.length() >= 4) {
                this.accPasswd = newPassword;
                return true;
            }
        }
        return false;
    }

    public String getMiniStatement() {
        if (transactions.isEmpty()) {
            return "No transactions recorded yet.";
        }
        String maskedAccount = "****" + accNumber.substring(Math.max(0, accNumber.length() - 4));
        StringBuilder sb = new StringBuilder("=== MINI STATEMENT ===\nAccount: " + maskedAccount + "\n----------------------\n");
        int start = Math.max(0, transactions.size() - 5);
        for (int i = start; i < transactions.size(); i++) {
            sb.append(transactions.get(i).toDisplayString()).append("\n");
        }
        sb.append("----------------------\nCurrent Bal: £").append(balance);
        return sb.toString();
    }

    public String getAccountTypeName() {
        return "STANDARD";
    }

    public int getTransactionCount() {
        return transactions.size();
    }
}